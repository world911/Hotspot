package com.hotspotkeeper

import android.content.Context
import android.os.Build

/** Simple settings storage. */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    // ---- how to turn the hotspot on ----

    /** Seconds to wait after airplane mode turns off, so radios come back first. */
    var delaySec: Int
        get() = p.getInt("delay", 5)
        set(v) { p.edit().putInt("delay", v).apply() }

    /** 0 = tap Quick Settings tile, 1 = silent (command, then tethering service), 2 = tile first then silent. */
    var method: Int
        get() = p.getInt("method", if (Build.VERSION.SDK_INT >= 31) 1 else 0)
        set(v) { p.edit().putInt("method", v).apply() }

    var command: String
        get() = p.getString("cmd", DEFAULT_CMD) ?: DEFAULT_CMD
        set(v) { p.edit().putString("cmd", v).apply() }

    /** Text to look for in the Quick Settings tile name. */
    var keyword: String
        get() = p.getString("kw", "hotspot") ?: "hotspot"
        set(v) { p.edit().putString("kw", v).apply() }

    /** Optional fixed screen position "x,y" of the hotspot tile (skips the slow screen search). */
    var tilePos: String
        get() = p.getString("tilepos", "") ?: ""
        set(v) { p.edit().putString("tilepos", v).apply() }

    // ---- features ----

    /** Turn the hotspot back on after airplane mode is switched off. */
    var keepOn: Boolean
        get() = p.getBoolean("keepOn", false)
        set(v) { p.edit().putBoolean("keepOn", v).apply() }

    /** Watchdog: turn the hotspot on whenever it is found off. */
    var watchdogOn: Boolean
        get() = p.getBoolean("wdOn", false)
        set(v) { p.edit().putBoolean("wdOn", v).apply() }

    var watchdogSec: Int
        get() = p.getInt("wdSec", 10)
        set(v) { p.edit().putInt("wdSec", v).apply() }

    /** Auto airplane toggle on a timer. */
    var autoOn: Boolean
        get() = p.getBoolean("autoOn", false)
        set(v) { p.edit().putBoolean("autoOn", v).apply() }

    /** Seconds between toggles. */
    var intervalSec: Int
        get() = p.getInt("intervalSec", p.getInt("interval", 30) * 60)
        set(v) { p.edit().putInt("intervalSec", v).apply() }

    /** How many times (0 = until stopped). */
    var times: Int
        get() = p.getInt("times", 10)
        set(v) { p.edit().putInt("times", v).apply() }

    /** Seconds airplane mode stays on each time. */
    var airSec: Int
        get() = p.getInt("airsec", 5)
        set(v) { p.edit().putInt("airsec", v).apply() }

    /** Only toggle airplane mode when the internet is down. */
    var smartToggle: Boolean
        get() = p.getBoolean("smart", false)
        set(v) { p.edit().putBoolean("smart", v).apply() }

    /** Only run auto toggle and watchdog between these hours. */
    var schedOn: Boolean
        get() = p.getBoolean("schedOn", false)
        set(v) { p.edit().putBoolean("schedOn", v).apply() }

    var schedStart: Int
        get() = p.getInt("schedStart", 8)
        set(v) { p.edit().putInt("schedStart", v).apply() }

    var schedEnd: Int
        get() = p.getInt("schedEnd", 23)
        set(v) { p.edit().putInt("schedEnd", v).apply() }

    // ---- state written by the service ----

    /** True while the background service should be running. */
    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) { p.edit().putBoolean("enabled", v).apply() }

    /** When the next auto toggle happens (epoch milliseconds, 0 = not set). */
    var nextAt: Long
        get() = p.getLong("nextAt", 0L)
        set(v) { p.edit().putLong("nextAt", v).apply() }

    /** Auto toggles completed so far. */
    var cycleN: Int
        get() = p.getInt("cycleN", 0)
        set(v) { p.edit().putInt("cycleN", v).apply() }

    var status: String
        get() = p.getString("status", "-") ?: "-"
        set(v) { p.edit().putString("status", v).apply() }

    companion object {
        const val DEFAULT_CMD = "cmd wifi start-softap MyHotspot wpa2 MyPassword123"
    }
}
