package com.hotspotkeeper

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home screen widget: one tap to start or stop Hotspot Keeper. */
class ToggleWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val c = Cfg(context)
            if (c.enabled) {
                Svc.stopAll(context)
            } else {
                c.keepOn = true
                Svc.sync(context)
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.hotspotkeeper.WIDGET_TOGGLE"

        fun refresh(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, ToggleWidget::class.java))
                if (ids.isEmpty()) return
                val on = Cfg(context).enabled
                val views = RemoteViews(context.packageName, R.layout.widget)
                views.setTextViewText(
                    R.id.widget_text,
                    if (on) "Hotspot Keeper: ON" else "Hotspot Keeper: OFF"
                )
                val pi = PendingIntent.getBroadcast(
                    context, 0,
                    Intent(context, ToggleWidget::class.java).setAction(ACTION_TOGGLE),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                views.setOnClickPendingIntent(R.id.widget_root, pi)
                mgr.updateAppWidget(ids, views)
            } catch (_: Exception) {
            }
        }
    }
}
