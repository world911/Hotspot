package com.hotspotkeeper

import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import java.lang.reflect.Proxy
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Silent hotspot start: shell command first, then Android's tethering service directly. */
object Tether {

    private val CODES = mapOf(
        0 to "OK",
        1 to "unknown interface",
        2 to "service unavailable",
        3 to "unsupported",
        4 to "interface unavailable",
        5 to "internal error",
        6 to "tether interface error",
        7 to "untether interface error",
        8 to "enable forwarding error",
        9 to "disable forwarding error",
        10 to "interface config error",
        11 to "provisioning failed",
        12 to "DHCP server error",
        13 to "entitlement unknown",
        14 to "no permission to change tethering",
        15 to "no permission to access tethering",
        16 to "unknown type"
    )

    fun silent(cfg: Cfg, log: (String) -> Unit): Boolean {
        if (Hotspot.isApUp()) {
            log("Hotspot already on")
            return true
        }
        if (Hotspot.runCommand(cfg.command, log)) {
            Thread.sleep(3000)
            log(if (Hotspot.isApUp()) "Hotspot is up" else "Command ran; hotspot interface not seen")
            return true
        }
        log("Command failed, trying tethering service")
        return direct(log)
    }

    fun direct(log: (String) -> Unit): Boolean {
        try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            val svc = SystemServiceHelper.getSystemService("tethering")
            if (svc == null) {
                log("Direct: no tethering service on this phone")
                return false
            }
            val stub = Class.forName("android.net.ITetheringConnector\$Stub")
            val conn = stub.getMethod("asInterface", IBinder::class.java)
                .invoke(null, ShizukuBinderWrapper(svc))
            if (conn == null) {
                log("Direct: could not connect to tethering service")
                return false
            }

            val reqCls = Class.forName("android.net.TetheringRequestParcel")
            val req = reqCls.getDeclaredConstructor().newInstance()
            fun setF(name: String, v: Any) {
                try { reqCls.getField(name).set(req, v) } catch (_: Exception) {}
            }
            setF("tetheringType", 0)
            setF("exemptFromEntitlementCheck", true)
            setF("showProvisioningUi", false)
            setF("connectivityScope", 1)

            val lisCls = Class.forName("android.net.IIntResultListener")
            val latch = CountDownLatch(1)
            var result = Int.MIN_VALUE
            val binder = object : Binder() {
                override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                    if (code == 1) {
                        try {
                            data.enforceInterface("android.net.IIntResultListener")
                            result = data.readInt()
                        } catch (_: Exception) {
                            result = -999
                        }
                        latch.countDown()
                        return true
                    }
                    return super.onTransact(code, data, reply, flags)
                }
            }
            val listener = Proxy.newProxyInstance(lisCls.classLoader, arrayOf(lisCls)) { _, m, _ ->
                if (m.name == "asBinder") binder else null
            }

            val m = conn.javaClass.methods.firstOrNull { it.name == "startTethering" }
                ?: run {
                    log("Direct: startTethering not found")
                    return false
                }
            val args: Array<Any?> = when (m.parameterTypes.size) {
                3 -> arrayOf(req, "com.android.shell", listener)
                4 -> arrayOf(req, "com.android.shell", null, listener)
                else -> {
                    log("Direct: unsupported method (${m.parameterTypes.size} args)")
                    return false
                }
            }
            m.invoke(conn, *args)
            val got = latch.await(6, TimeUnit.SECONDS)
            Thread.sleep(2000)
            val up = Hotspot.isApUp()
            if (got) {
                log("Direct: reply code $result (${CODES[result] ?: "unknown"}). Hotspot interface up: $up")
            } else {
                log("Direct: no reply from system. Hotspot interface up: $up")
            }
            if (!up) {
                val links = Shell.run("ip -o link").out.lines()
                    .mapNotNull { Regex("^\\d+:\\s+([^:@\\s]+)").find(it)?.groupValues?.get(1) }
                log("Interfaces now: ${links.joinToString(" ")}")
            }
            return up || (got && result == 0)
        } catch (e: Exception) {
            val c = e.cause ?: e
            log("Direct failed: ${c.javaClass.simpleName}: ${c.message}")
            return false
        }
    }
}
