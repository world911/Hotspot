package com.hotspotkeeper

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var cfg: Cfg
    private var dark = false

    // header and setup
    private lateinit var shizukuText: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var setupText: TextView

    // status
    private lateinit var hotspotText: TextView
    private lateinit var airText: TextView
    private lateinit var countText: TextView
    private lateinit var lastText: TextView

    // switches
    private lateinit var keepSwitch: Switch
    private lateinit var wdSwitch: Switch
    private lateinit var autoSwitch: Switch
    private lateinit var smartSwitch: Switch
    private lateinit var schedSwitch: Switch

    // fields
    private lateinit var wdEdit: EditText
    private lateinit var intervalEdit: EditText
    private lateinit var timesEdit: EditText
    private lateinit var airEdit: EditText
    private lateinit var startEdit: EditText
    private lateinit var endEdit: EditText
    private lateinit var delayEdit: EditText
    private lateinit var kwEdit: EditText
    private lateinit var posEdit: EditText
    private lateinit var cmdEdit: EditText
    private lateinit var methodBtn: Button

    // tools
    private lateinit var toolsBody: LinearLayout
    private lateinit var toolsHeader: TextView
    private lateinit var logText: TextView

    private var syncing = false
    private var tick = 0
    private val logBuf = StringBuilder()
    private val handler = Handler(Looper.getMainLooper())

    @Volatile
    private var hsUp = -1

    @Volatile
    private var testThread: Thread? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            if (tick % 3 == 0) pollHotspot()
            tick++
            handler.postDelayed(this, 1000)
        }
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }

    // ---------- colors ----------
    private fun col(d: String, l: String) = Color.parseColor(if (dark) d else l)
    private fun cBg() = col("#0F1115", "#F3F4F8")
    private fun cCard() = col("#1A1D24", "#FFFFFF")
    private fun cField() = col("#262A33", "#EEF0F5")
    private fun cText() = col("#E8EAED", "#1B1E24")
    private fun cSub() = col("#9AA0A6", "#6B7280")
    private fun cAccent() = col("#4F8CFF", "#2F6BFF")
    private fun cGood() = col("#4CD964", "#1E9E3A")
    private fun cBad() = col("#FF6B6B", "#D93025")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        actionBar?.hide()
        window.statusBarColor = cBg()
        window.navigationBarColor = cBg()
        window.decorView.systemUiVisibility =
            if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        Shizuku.addRequestPermissionResultListener(permListener)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(28))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg())
            addView(root)
        })

        root.addView(label("Hotspot Keeper", 28f, cText(), true))
        shizukuText = label("", 13f, cSub())
        root.addView(shizukuText)

        // ---- setup checklist (hidden once everything is ready) ----
        setupCard = card()
        setupCard.addView(label("Setup", 16f, cText(), true))
        setupText = label("", 14f, cText()).apply { setPadding(0, dp(8), 0, dp(4)) }
        setupCard.addView(setupText)
        setupCard.addView(pill("Grant Shizuku permission", true) { requestShizuku() })
        setupCard.addView(pill("Allow background running", false) { batteryExempt() })
        root.addView(setupCard)

        // ---- live status ----
        val sCard = card()
        hotspotText = label("", 20f, cText(), true)
        airText = label("", 16f, cText())
        countText = label("", 14f, cAccent(), true).apply { setPadding(0, dp(8), 0, 0) }
        lastText = label("", 12f, cSub()).apply { setPadding(0, dp(6), 0, 0) }
        sCard.addView(hotspotText)
        sCard.addView(airText)
        sCard.addView(countText)
        sCard.addView(lastText)
        sCard.addView(pill("Stop everything", false) { stopAll() })
        root.addView(sCard)

        // ---- keep hotspot on + watchdog ----
        val c1 = card()
        keepSwitch = Switch(this)
        c1.addView(switchRow("Keep hotspot on", "Turns it back on after airplane mode", keepSwitch))
        c1.addView(divider())
        wdSwitch = Switch(this)
        c1.addView(switchRow("Hotspot watchdog", "Turns it on again whenever it is found off", wdSwitch))
        val wdRow = row()
        wdRow.addView(numBox("Check every (sec)", cfg.watchdogSec.toString()) { wdEdit = it }, lp(0, -2, 1f, 0))
        c1.addView(wdRow)
        root.addView(c1)

        // ---- auto airplane toggle ----
        val c2 = card()
        autoSwitch = Switch(this)
        c2.addView(switchRow("Auto airplane toggle", "Cycles airplane mode on a timer", autoSwitch))
        val r2 = row()
        r2.addView(numBox("Every (sec)", cfg.intervalSec.toString()) { intervalEdit = it }, lp(0, -2, 1f, 10))
        r2.addView(numBox("Times (0=inf)", cfg.times.toString()) { timesEdit = it }, lp(0, -2, 1f, 10))
        r2.addView(numBox("Stay on (sec)", cfg.airSec.toString()) { airEdit = it }, lp(0, -2, 1f, 0))
        c2.addView(r2)
        smartSwitch = Switch(this)
        c2.addView(switchRow("Only when internet is down", "Skips the toggle if internet works", smartSwitch).apply {
            setPadding(0, dp(14), 0, 0)
        })
        root.addView(c2)

        // ---- schedule ----
        val c3 = card()
        schedSwitch = Switch(this)
        c3.addView(switchRow("Schedule", "Run auto toggle and watchdog only between these hours", schedSwitch))
        val r3 = row()
        r3.addView(numBox("From hour (0-23)", cfg.schedStart.toString()) { startEdit = it }, lp(0, -2, 1f, 10))
        r3.addView(numBox("Until hour (0-23)", cfg.schedEnd.toString()) { endEdit = it }, lp(0, -2, 1f, 0))
        c3.addView(r3)
        root.addView(c3)

        // ---- tools and log (collapsed) ----
        val tools = collapsible(TOOLS_TITLE)
        toolsBody = tools.second
        toolsHeader = tools.third
        toolsBody.addView(pill("Test hotspot on", true) { test() })
        toolsBody.addView(pill("Test airplane toggle", false) { testAirplane() })
        toolsBody.addView(pill("Run diagnostics", false) { diagnostics() })
        logText = label("Nothing yet. Tap a test button.", 12f, cSub()).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, dp(12), 0, 0)
        }
        toolsBody.addView(logText)
        toolsBody.addView(pill("Copy log", false) { copyLog() })
        root.addView(tools.first)

        // ---- advanced (collapsed) ----
        val adv = collapsible(ADV_TITLE)
        val advBody = adv.second
        methodBtn = pill(methodName(cfg.method), false) {
            cfg.method = (cfg.method + 1) % 3
            methodBtn.text = methodName(cfg.method)
        }
        advBody.addView(label("Method (tap to change). Default: tile on Android 11 and older, silent on 12 and newer", 12f, cSub()).apply {
            setPadding(0, dp(12), 0, 0)
        })
        advBody.addView(methodBtn)
        advBody.addView(small("Wait after airplane mode off (sec)"))
        delayEdit = inputBox(cfg.delaySec.toString(), true)
        advBody.addView(delayEdit)
        advBody.addView(small("Tile name(s), comma separated"))
        kwEdit = inputBox(cfg.keyword, false)
        advBody.addView(kwEdit)
        advBody.addView(small("Fixed tile position x,y (optional, example 590,1187)"))
        posEdit = inputBox(cfg.tilePos, false)
        advBody.addView(posEdit)
        advBody.addView(small("Shell command (silent method)"))
        cmdEdit = inputBox(cfg.command, false)
        advBody.addView(cmdEdit)
        root.addView(adv.first)

        // ---- listeners ----
        keepSwitch.setOnCheckedChangeListener { _, on ->
            if (!syncing) {
                cfg.keepOn = on
                Svc.sync(this)
                warnShizuku(on)
            }
        }
        wdSwitch.setOnCheckedChangeListener { _, on ->
            if (!syncing) {
                cfg.watchdogOn = on
                Svc.sync(this)
                warnShizuku(on)
            }
        }
        autoSwitch.setOnCheckedChangeListener { _, on ->
            if (!syncing) {
                if (on) {
                    cfg.cycleN = 0
                    cfg.nextAt = 0L
                } else {
                    cfg.nextAt = 0L
                }
                cfg.autoOn = on
                Svc.sync(this)
                warnShizuku(on)
            }
        }
        smartSwitch.setOnCheckedChangeListener { _, on -> if (!syncing) cfg.smartToggle = on }
        schedSwitch.setOnCheckedChangeListener { _, on -> if (!syncing) cfg.schedOn = on }

        for (e in listOf(wdEdit, intervalEdit, timesEdit, airEdit, startEdit, endEdit, delayEdit, kwEdit, posEdit, cmdEdit)) {
            watch(e)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        tick = 0
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------- logic ----------

    private fun methodName(m: Int) = when (m) {
        0 -> "Tap Quick Settings tile"
        1 -> "Silent (command, then tethering service)"
        else -> "Tap tile, then silent if that fails"
    }

    private fun watch(e: EditText) {
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                saveFields()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun num(e: EditText, def: Int) = e.text.toString().trim().toIntOrNull() ?: def

    private fun saveFields() {
        cfg.delaySec = num(delayEdit, 5).coerceAtLeast(0)
        cfg.keyword = kwEdit.text.toString().ifBlank { "hotspot" }
        cfg.tilePos = posEdit.text.toString().trim()
        cfg.command = cmdEdit.text.toString()
        cfg.watchdogSec = num(wdEdit, 10).coerceAtLeast(5)
        cfg.intervalSec = num(intervalEdit, 60).coerceAtLeast(5)
        cfg.times = num(timesEdit, 10).coerceAtLeast(0)
        cfg.airSec = num(airEdit, 5).coerceAtLeast(2)
        cfg.schedStart = num(startEdit, 8).coerceIn(0, 23)
        cfg.schedEnd = num(endEdit, 23).coerceIn(0, 23)
    }

    private fun warnShizuku(on: Boolean) {
        if (on && !Svc.shizukuReady()) toast("Shizuku is not ready yet. Actions will wait for it.")
    }

    private fun airplaneOn(): Boolean =
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun fmt(s: Long) = String.format("%d:%02d", s / 60, s % 60)

    private fun refresh() {
        val running = Svc.shizukuRunning()
        val perm = Svc.shizukuReady()
        val batt = try {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        } catch (_: Exception) {
            true
        }

        shizukuText.text = when {
            !running -> "Shizuku is not running. Open Shizuku and start it."
            !perm -> "Shizuku is running, permission not granted"
            else -> "Shizuku ready"
        }
        setupCard.visibility = if (running && perm && batt) View.GONE else View.VISIBLE
        setupText.text = (if (running) "✓" else "✗") + " Shizuku running\n" +
            (if (perm) "✓" else "✗") + " Permission granted\n" +
            (if (batt) "✓" else "✗") + " Background running allowed"

        val hs = hsUp
        hotspotText.text = "Hotspot: " + when (hs) {
            1 -> "ON"
            0 -> "OFF"
            else -> "unknown"
        }
        hotspotText.setTextColor(if (hs == 1) cGood() else if (hs == 0) cBad() else cSub())
        airText.text = "Airplane mode: " + if (airplaneOn()) "ON" else "OFF"

        if (cfg.autoOn) {
            val total = if (cfg.times > 0) " of " + cfg.times else ""
            val left = cfg.nextAt - System.currentTimeMillis()
            val next = if (cfg.nextAt == 0L) "starting" else "in " + fmt((left / 1000).coerceAtLeast(0))
            countText.text = "Next toggle $next  ·  done " + cfg.cycleN + total
        } else {
            countText.text = "Auto toggle is off"
        }
        lastText.text = "Last: " + cfg.status

        syncing = true
        keepSwitch.isChecked = cfg.keepOn
        wdSwitch.isChecked = cfg.watchdogOn
        autoSwitch.isChecked = cfg.autoOn
        smartSwitch.isChecked = cfg.smartToggle
        schedSwitch.isChecked = cfg.schedOn
        syncing = false
    }

    private fun pollHotspot() {
        if (!Svc.shizukuReady()) {
            hsUp = -1
            return
        }
        Thread {
            hsUp = try {
                if (Hotspot.isApUp()) 1 else 0
            } catch (_: Exception) {
                -1
            }
        }.start()
    }

    private fun stopAll() {
        testThread?.interrupt()
        testThread = null
        Svc.stopAll(this)
        logLine("Stopped everything")
        toast("Stopped")
        refresh()
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Start Shizuku first")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refresh()
                return
            }
            Shizuku.requestPermission(100)
        } catch (e: Exception) {
            toast("Shizuku error: ${e.message}")
        }
    }

    private fun batteryExempt() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun logLine(s: String) {
        runOnUiThread {
            logBuf.append(s).append('\n')
            logText.text = logBuf.toString()
        }
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()))
        toast("Log copied")
    }

    private fun runBg(title: String, work: () -> Unit) {
        saveFields()
        showTools()
        if (!Svc.shizukuReady()) {
            logLine("Shizuku is not ready. Start Shizuku and grant permission.")
            return
        }
        logLine("--- $title ---")
        testThread?.interrupt()
        testThread = Thread {
            try {
                work()
            } catch (_: InterruptedException) {
                logLine("Stopped")
            } catch (e: Exception) {
                logLine("Error: ${e.javaClass.simpleName}: ${e.message}")
            }
        }.also { it.start() }
    }

    private fun test() = runBg("Test hotspot on (wait until Result appears)") {
        val ok = Hotspot.enable(cfg) { logLine(it) }
        logLine(if (ok) "Result: OK" else "Result: FAILED")
    }

    private fun testAirplane() = runBg("Test airplane toggle") {
        logLine("Airplane ON...")
        val a = Hotspot.setAirplane(true) { logLine(it) }
        Thread.sleep(cfg.airSec * 1000L)
        logLine("Airplane OFF...")
        val b = Hotspot.setAirplane(false) { logLine(it) }
        logLine(if (a && b) "Result: OK" else "Result: FAILED")
    }

    private fun diagnostics() = runBg("Diagnostics") {
        Hotspot.diagnose { logLine(it) }
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, right: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { rightMargin = dp(right) }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(cCard(), 18)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(12), 0, 0)
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(cField())
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(14)
            bottomMargin = dp(14)
        }
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun small(s: String) = label(s, 12f, cSub()).apply { setPadding(0, dp(12), 0, dp(4)) }

    private fun switchRow(title: String, sub: String, sw: Switch): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val colm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colm.addView(label(title, 17f, cText(), true))
        colm.addView(label(sub, 12f, cSub()))
        r.addView(colm, LinearLayout.LayoutParams(0, -2, 1f))
        sw.scaleX = 1.2f
        sw.scaleY = 1.2f
        r.addView(sw)
        return r
    }

    private fun inputBox(value: String, number: Boolean) = EditText(this).apply {
        setText(value)
        setSingleLine(true)
        setTextColor(cText())
        setHintTextColor(cSub())
        textSize = 15f
        background = rounded(cField(), 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (number) {
            inputType = InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
        }
    }

    private fun numBox(caption: String, value: String, out: (EditText) -> Unit): View {
        val colm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colm.addView(label(caption, 12f, cSub()))
        val e = inputBox(value, true)
        out(e)
        colm.addView(e, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        return colm
    }

    private fun pill(title: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = title
        transformationMethod = null
        textSize = 15f
        stateListAnimator = null
        setTextColor(if (filled) Color.WHITE else cAccent())
        background = rounded(if (filled) cAccent() else cField(), 14)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }

    /** A card whose body is hidden until the title is tapped. Returns card, body, header. */
    private fun collapsible(title: String): Triple<LinearLayout, LinearLayout, TextView> {
        val c = card()
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val header = label("$title  ▸", 16f, cText(), true).apply { setPadding(0, dp(4), 0, dp(4)) }
        header.setOnClickListener {
            setOpen(body, header, title, body.visibility != View.VISIBLE)
        }
        c.addView(header)
        c.addView(body)
        return Triple(c, body, header)
    }

    private fun setOpen(body: View, header: TextView, title: String, open: Boolean) {
        body.visibility = if (open) View.VISIBLE else View.GONE
        header.text = if (open) "$title  ▾" else "$title  ▸"
    }

    private fun showTools() {
        runOnUiThread { setOpen(toolsBody, toolsHeader, TOOLS_TITLE, true) }
    }

    companion object {
        const val TOOLS_TITLE = "Tools and log"
        const val ADV_TITLE = "Advanced settings"
    }
}
