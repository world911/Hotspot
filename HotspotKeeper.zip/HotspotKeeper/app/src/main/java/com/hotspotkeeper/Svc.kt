package com.hotspotkeeper

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Helpers shared by the screen, the widget and the service. */
object Svc {

    fun shizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    /** Starts or stops the background service depending on which features are switched on. */
    fun sync(ctx: Context) {
        val c = Cfg(ctx)
        val need = c.keepOn || c.watchdogOn || c.autoOn
        c.enabled = need
        val i = Intent(ctx, KeeperService::class.java)
        try {
            if (need) ctx.startForegroundService(i) else ctx.stopService(i)
        } catch (_: Exception) {
        }
        ToggleWidget.refresh(ctx)
    }

    /** Switches every feature off and stops the service. */
    fun stopAll(ctx: Context) {
        val c = Cfg(ctx)
        c.keepOn = false
        c.watchdogOn = false
        c.autoOn = false
        c.nextAt = 0L
        sync(ctx)
    }
}
