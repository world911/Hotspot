package com.hotspotkeeper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.os.IBinder
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Background engine. One loop runs every second and handles:
 * - auto airplane toggle (timer, cycle count, schedule, smart mode)
 * - hotspot watchdog
 * and a receiver turns the hotspot back on after airplane mode is switched off.
 */
class KeeperService : Service() {

    private lateinit var cfg: Cfg
    private val hotspotBusy = AtomicBoolean(false)
    private val toggleBusy = AtomicBoolean(false)

    @Volatile
    private var loop: Thread? = null
    private var wdFails = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (airplaneOn()) {
                save("Airplane mode on")
            } else if (cfg.keepOn) {
                restore()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        cfg = Cfg(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Hotspot Keeper", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, buildNote("Starting"))
        registerReceiver(receiver, IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED))
        save("Service started")
        startLoop()
        ToggleWidget.refresh(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ALL) {
            Svc.stopAll(this)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        loop?.interrupt()
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        ToggleWidget.refresh(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------------------------------------------------------- loop

    private fun startLoop() {
        if (loop?.isAlive == true) return
        loop = Thread { runLoop() }.also { it.start() }
    }

    private fun runLoop() {
        var lastWd = 0L
        var lastNote = 0L
        try {
            while (true) {
                val now = System.currentTimeMillis()
                try {
                    if (cfg.autoOn) autoStep(now)
                    if (cfg.watchdogOn && now - lastWd >= maxOf(cfg.watchdogSec, 5) * 1000L) {
                        lastWd = now
                        watchdogStep()
                    }
                    if (now - lastNote >= 5000L) {
                        lastNote = now
                        getSystemService(NotificationManager::class.java)
                            .notify(1, buildNote(noteText(System.currentTimeMillis())))
                    }
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Exception) {
                    save("Error: ${e.message}")
                }
                Thread.sleep(1000)
            }
        } catch (_: InterruptedException) {
        }
    }

    // ---------------------------------------------------------------- auto toggle

    private fun autoStep(now: Long) {
        val iv = maxOf(cfg.intervalSec, 5) * 1000L
        if (cfg.nextAt == 0L || (cfg.nextAt < now - 60_000L && !toggleBusy.get())) {
            cfg.nextAt = now + iv
            return
        }
        if (now < cfg.nextAt) return
        if (!toggleBusy.compareAndSet(false, true)) return
        Thread {
            try {
                doToggle(iv)
            } catch (_: InterruptedException) {
            } catch (e: Exception) {
                save("Auto toggle error: ${e.message}")
            } finally {
                toggleBusy.set(false)
            }
        }.start()
    }

    private fun doToggle(iv: Long) {
        if (!Svc.shizukuReady()) {
            save("Waiting for Shizuku")
            cfg.nextAt = System.currentTimeMillis() + 10_000L
            return
        }
        if (!inSchedule()) {
            save("Outside schedule, skipping")
            cfg.nextAt = System.currentTimeMillis() + iv
            return
        }
        if (cfg.smartToggle && Net.online()) {
            save("Internet is fine, skipping toggle")
            cfg.nextAt = System.currentTimeMillis() + iv
            return
        }
        val n = cfg.cycleN + 1
        val total = cfg.times
        save("Toggle " + n + (if (total > 0) "/$total" else "") + ": airplane on")
        Hotspot.setAirplane(true)
        Thread.sleep(maxOf(cfg.airSec, 2) * 1000L)
        Hotspot.setAirplane(false)
        cfg.cycleN = n
        if (total > 0 && n >= total) {
            cfg.autoOn = false
            cfg.nextAt = 0L
            save("Auto toggle finished ($n cycles)")
            Svc.sync(this)
        } else {
            cfg.nextAt = System.currentTimeMillis() + iv
        }
    }

    // ---------------------------------------------------------------- watchdog

    private fun watchdogStep() {
        if (airplaneOn() || toggleBusy.get() || hotspotBusy.get()) return
        if (!Svc.shizukuReady() || !inSchedule()) return
        if (Hotspot.isApUp()) {
            wdFails = 0
            return
        }
        if (!hotspotBusy.compareAndSet(false, true)) return
        try {
            save("Watchdog: hotspot is off, turning it on")
            Hotspot.enable(cfg) { save(it) }
            Thread.sleep(3000)
            if (Hotspot.isApUp()) {
                wdFails = 0
                save("Watchdog: hotspot is on")
            } else {
                wdFails++
                save("Watchdog: hotspot still off ($wdFails/3)")
                if (wdFails >= 3) {
                    wdFails = 0
                    cfg.watchdogOn = false
                    save("Watchdog switched itself off: hotspot would not turn on. Use Test hotspot on.")
                    Svc.sync(this)
                }
            }
        } finally {
            hotspotBusy.set(false)
        }
    }

    // ---------------------------------------------------------------- restore after airplane

    private fun restore() {
        if (!hotspotBusy.compareAndSet(false, true)) return
        Thread {
            try {
                Thread.sleep(cfg.delaySec * 1000L)
                if (!Svc.shizukuReady()) {
                    save("Shizuku not ready, cannot restore hotspot")
                    return@Thread
                }
                var ok = false
                for (i in 1..3) {
                    ok = Hotspot.enable(cfg) { save(it) }
                    if (ok) break
                    Thread.sleep(3000)
                }
                save(if (ok) "Hotspot restored" else "Failed to restore hotspot")
            } catch (_: InterruptedException) {
            } catch (e: Exception) {
                save("Error: ${e.message}")
            } finally {
                hotspotBusy.set(false)
            }
        }.start()
    }

    // ---------------------------------------------------------------- helpers

    private fun airplaneOn(): Boolean =
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun inSchedule(): Boolean {
        if (!cfg.schedOn) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val s = cfg.schedStart
        val e = cfg.schedEnd
        return when {
            s == e -> true
            s < e -> h >= s && h < e
            else -> h >= s || h < e
        }
    }

    private fun noteText(now: Long): String {
        val parts = ArrayList<String>()
        if (cfg.keepOn) parts.add("keeping hotspot on")
        if (cfg.watchdogOn) parts.add("watchdog")
        if (cfg.autoOn) {
            val left = ((cfg.nextAt - now) / 1000).coerceAtLeast(0)
            val total = if (cfg.times > 0) "/" + cfg.times else ""
            parts.add("next toggle in " + left + "s (" + cfg.cycleN + total + " done)")
        }
        return if (parts.isEmpty()) "Idle" else parts.joinToString(", ")
    }

    private fun buildNote(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, KeeperService::class.java).setAction(ACTION_STOP_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop",
            stop
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Hotspot Keeper")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    private fun save(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        cfg.status = "$t  $msg"
    }

    companion object {
        const val CHANNEL = "keeper2"
        const val ACTION_STOP_ALL = "com.hotspotkeeper.STOP_ALL"
    }
}
