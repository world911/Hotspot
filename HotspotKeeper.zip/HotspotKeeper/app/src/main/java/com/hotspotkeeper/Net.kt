package com.hotspotkeeper

import java.net.HttpURLConnection
import java.net.URL

object Net {

    /** True if the phone has working internet (checks two well known test pages). */
    fun online(): Boolean {
        val urls = listOf(
            "https://www.google.com/generate_204",
            "https://cp.cloudflare.com/generate_204"
        )
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.instanceFollowRedirects = false
                val code = c.responseCode
                c.disconnect()
                if (code == 204) return true
            } catch (_: Exception) {
            }
        }
        return false
    }
}
